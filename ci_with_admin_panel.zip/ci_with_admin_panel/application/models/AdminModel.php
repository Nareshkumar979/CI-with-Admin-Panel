<?php 
defined('BASEPATH') OR exit('No direct script access allowed');

class AdminModel extends CI_Model
{
	
	function __construct()
	{
		parent::__construct();
	}

	public function getAdminUser($email,$password)
	{
		$this->db->select('*');
		$this->db->from('admin_user');
		$this->db->where('email_id',$email);
		$this->db->where('password',$password);
		$this->db->where('status',1);
		$this->db->where('delete_status',0);
		$query = $this->db->get()->row();
		return $query;
	}

	public function update_admin_data($data,$edit_id)
	{
		$this->db->where('adm_user_id',$edit_id);
		$this->db->update('admin_user',$data);
	}

}