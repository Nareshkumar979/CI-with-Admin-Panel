<footer class="main-footer">
    <div class="pull-right hidden-xs">
      <b>Designed & Developed by </b><a href="#" target="_blank"> Developer Name</a>.
    </div>
    <strong>Copyright &copy; <?php echo date('Y');?> <a href="#">College Pages</a>.</strong> All rights
    reserved.
</footer>
