<!-- Content Header (Page header) -->
<section class="content-header">
  <h1>
     Profile
    <small>Edit Profile</small>
  </h1>
  <ol class="breadcrumb">
    <li><a href="<?php echo base_url('ci-admin/home');?>"><i class="fa fa-dashboard"></i> Home</a></li>
  </ol>
</section>
<!-- Main content -->
<section class="content">
  <?php $admin_user_data= get_adm_user($this->session->userdata['session_data']['admin_user_id']);?>
   <?php
    if(count($admin_user_data)==0){}
    else
    {
  ?>
  <?php echo form_open('AdminController/update_admin'); ?>
  <!-- Default box -->
  <div class="col-sm-6">
  <div class="box">
    <div class="box-header with-border">
      <h3 class="box-title">Admin Profile</h3>
    </div>
    <div class="box-body">
      <div class="form-group">
        <label for="exampleInputEmail1">User Name</label>
        <input type="hidden" name="edit_id" value="<?php echo $admin_user_data->adm_user_id;?>">
        <input type="text" name="user_name" class="form-control" id="exampleInputEmail1" placeholder="Enter User Name Here..." value="<?php echo $admin_user_data->user_name;?>" required autocomplete="off">
      </div>
      <div class="form-group">
        <label for="exampleInputEmail1">Email</label>
        <input type="email" name="email_id" class="form-control" id="exampleInputEmail1" placeholder="Enter Email Address Here..." value="<?php echo $admin_user_data->email_id;?>" required autocomplete="off">
      </div>
      <div class="form-group">
        <label for="exampleInputPassword1">New Password &nbsp;<small>(Type New Password and Hit Save if you want to reset your old password)</small></label>
        <input type="password" name="password" class="form-control" id="exampleInputPassword1" placeholder="Enter Password Here..." value="<?php echo $admin_user_data->password;?>" required autocomplete="off">
      </div>
    </div>
    <!-- /.box-body -->
    <div class="box-footer">
      <input type="submit" name="save" class="btn btn-primary pull-right" value="Update">
    </div>
    <!-- /.box-footer-->
  </div>
  <!-- /.box -->
</div>
  <?php echo form_close();?>
  <?php 
    }
  ?>
</section>
<!-- /.content -->