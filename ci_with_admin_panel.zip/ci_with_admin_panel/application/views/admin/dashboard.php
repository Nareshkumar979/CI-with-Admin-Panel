<!-- Content Header (Page header) -->
<section class="content-header">
  <h1>
    Dashboard
    <small>Home Page</small>
  </h1>
  <ol class="breadcrumb">
    <li><a href="<?php echo base_url('cpin-admin/home');?>"><i class="fa fa-dashboard"></i> Home</a></li>
  </ol>
</section>
<!-- Main content -->
<section class="content">
<h1 style="text-align:center;">Welcome to <?php echo FULL_PROJECT_NAME; ?></h1>
</section>
<!-- /.content -->