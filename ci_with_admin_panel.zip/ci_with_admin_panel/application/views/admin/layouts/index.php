<!DOCTYPE html>
<html>
 <?php if($header_scripts) echo $header_scripts; ?>
 <body class="hold-transition skin-yellow sidebar-mini">
<div class="wrapper">
<?php if($header) echo $header; ?>	
<?php if($navigations) echo $navigations; ?>
    <div class="content-wrapper">
      <?php if($middle) echo $middle; ?>
    </div>
<?php if($footer) echo $footer; ?>
<?php if($footer_scripts) echo $footer_scripts; ?>
</div>
</body>
</html>
