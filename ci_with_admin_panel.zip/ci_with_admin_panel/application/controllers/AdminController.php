<?php 
defined('BASEPATH') OR exit('No direct script access allowed');

class AdminController extends MY_Controller
{
	
	function __construct()
	{
		parent::__construct();
		$this->load->model('AdminModel');
	}

	public function index()
	{
		if (isset($this->session->userdata['session_data'])) 
		{
            redirect('ci-admin/home');
       	}
       	else
       	{
       	 	$this->load->view('admin/index');
       	}
		
	}

	public function login()
	{
		
		$email = $this->input->post('email');
		$password = $this->input->post('password');
		$result= $this->AdminModel->getAdminUser($email,$password);

		if(count($result)==0)
		{	
			$this->session->set_flashdata('msg', '<div class="alert alert-danger alert-dismissable"><button type="button" class="close" data-dismiss="alert">&times;</button><strong>Invalid Username or Password!</strong></div>');
			redirect('ci-admin');
		}
		else
		{
			$data = array(
                    	'admin_user_id' => $result->adm_user_id,
                    	'user_name'=>$result->user_name,  
                	);
			$this->session->set_flashdata('msg', '<div class="alert alert-success alert-dismissable"><button type="button" class="close" data-dismiss="alert">&times;</button><strong>Invalid Username or Password!</strong></div>');
			$this->session->set_userdata('session_data', $data);
			redirect('ci-admin/home');
		}
		
	}

	public function home()
	{
		if (!isset($this->session->userdata['session_data'])) 
		{
	          redirect('ci-admin');
       	}
       	else
       	{
       		$datas['']="";
			$this->template['middle'] = $this->load->view($this->middle ='admin/dashboard',$datas,true);
			$this->admin_layout();
       	}
	}

	public function profile()
	{
			if (!isset($this->session->userdata['session_data'])) 
			{
	          	redirect('admin');
	       	}
	       else
	       {
	       		$datas['']="";
				$this->template['middle'] = $this->load->view($this->middle ='admin/profile',$datas,true);
				$this->admin_layout();
	       }
	}

	public function update_admin()
	{
		$edit_id = $this->input->post('edit_id');
		$user_name = $this->input->post('user_name');
		$email_id = $this->input->post('email_id');
		$password = $this->input->post('password');
		$data = array(
			'user_name' =>$user_name ,
			'email_id' =>$email_id ,
			'password' => $password,
			 );
		$this->AdminModel->update_admin_data($data,$edit_id);
		redirect('ci-admin/profile');
	}

	public function logout()
	{
        $data = array(
		'admin_user_id' => '',
		'user_name' => ''
		);
	$this->session->unset_userdata('session_data', $data);
 	redirect('ci-admin');
	}
}