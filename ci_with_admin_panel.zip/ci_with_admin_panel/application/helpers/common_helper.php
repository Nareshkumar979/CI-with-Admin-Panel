<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

function get_adm_user($id)
{
    $ci =& get_instance();
    $ci->load->database();
    $ci->db->select('*');
    $ci->db->from('admin_user');
    $ci->db->where('adm_user_id',$id);
    $ci->db->where('status',1);
    $ci->db->where('delete_status',0);
    $query=$ci->db->get()->row();
    return $query;
}