<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class MY_Controller extends CI_Controller{

   var $template  = array();
   var $data      = array();
   public function admin_layout()
   {
     $this->template['header_scripts'] = $this->load->view('admin/includes/header_scripts', $this->data, true);
     $this->template['header'] = $this->load->view('admin/includes/header', $this->data, true);
     $this->template['navigations'] = $this->load->view('admin/includes/navigations', $this->data, true);
     $this->template['middle'] = $this->load->view($this->middle, $this->data, true);
     $this->template['footer'] = $this->load->view('admin/includes/footer', $this->data, true);
     $this->template['footer_scripts'] = $this->load->view('admin/includes/footer_scripts', $this->data, true);     
     $this->load->view('admin/layouts/index', $this->template);
   }

   public function frontend_layout()
   {
     $this->template['header_scripts'] = $this->load->view('frontend/includes/header_scripts', $this->data, true);
     $this->template['header'] = $this->load->view('frontend/includes/header', $this->data, true);
     $this->template['middle'] = $this->load->view($this->middle, $this->data, true);
     $this->template['footer'] = $this->load->view('frontend/includes/footer', $this->data, true);
     $this->template['footer_scripts'] = $this->load->view('frontend/includes/footer_scripts', $this->data, true);
     $this->load->view('frontend/layouts/index', $this->template);
   }

 }